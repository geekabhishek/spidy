<?php 

//his 
$wp_automatic_fb_xs = '31%3ADeFLESQzO2qLlQ%3A2%3A1630777636%3A-1%3A2197';
$wp_automatic_fb_cuser = '588305104';

/*//mine 
$wp_automatic_fb_xs = '14%3AaOTkBRkP0wUYcA%3A2%3A1627746026%3A-1%3A6570%3A%3AAcV7PjBmd1C5EN9EWaZ3UQj-PQo2Qf1dVgGIqnAtXNgT';
$wp_automatic_fb_cuser = '1475120237';
*/

//curl ini
$ch = curl_init();
curl_setopt($ch, CURLOPT_HEADER,0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT,20);
curl_setopt($ch, CURLOPT_REFERER, 'http://www.bing.com/');
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36');
curl_setopt($ch, CURLOPT_MAXREDIRS, 5); // Good leeway for redirections.
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // Many login forms redirect at least once.
curl_setopt($ch, CURLOPT_COOKIEJAR , "cookie.txt");


//curl get
$x='error';
$url='https://www.facebook.com/100050608684035/posts/382974380066182';
$url = 'https://www.facebook.com/momosalah/posts/415352513283045';
curl_setopt($ch, CURLOPT_HTTPGET, 1);
curl_setopt($ch, CURLOPT_URL, trim($url));

curl_setopt ( $ch, CURLOPT_COOKIE, 'xs=' . $wp_automatic_fb_xs . ';c_user=' . $wp_automatic_fb_cuser  );
curl_setopt ( $ch,CURLOPT_HTTPHEADER, array('sec-fetch-site: none', 'sec-fetch-mode: navigate','sec-fetch-user: ?1','sec-fetch-dest: document' ));

$headers [] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
$headers [] = "Sec-Fetch-User: ?1";
curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );

$exec=curl_exec($ch);
$x=curl_error($ch);



echo $exec.$x;

?>